namespace GramaticiLR1
{
  internal class Gramatica
  {
    private List<string> terminale = new();
    private List<string> neterminale = new();
    private readonly List<string> productii = new();
    private readonly Dictionary<(int nr, char cheie), string> tabelaActiuniSiSalt = new();
    private int randuri = 0;
    private readonly string sir = " ";

    public Gramatica(string sir)
    {
      this.sir = sir;
      Citire();
      Afisare();
    }

    public void CitireTabela(string filePath)
    {
      randuri = 0;
      foreach (string line in File.ReadLines(filePath))
      {
        int j = 0;
        string[] cuv = line.Split(" ");
        if (cuv.Length == neterminale.Count + terminale.Count + 1)
        {
          foreach (string s in terminale)
          {
            tabelaActiuniSiSalt[(randuri, Char.Parse(s))] = cuv[j++];
          }
          tabelaActiuniSiSalt[(randuri, '$')] = cuv[j++];
          foreach (string s in neterminale)
          {
            tabelaActiuniSiSalt[(randuri, Char.Parse(s))] = cuv[j++];
          }
          randuri++;
        }
        else { Console.WriteLine("Matricea introdusa nu este corecta"); }
      }
    }

    public void AfisareTabela()
    {
      Console.Write("   ");
      foreach (string s in terminale)
        Console.Write("{0}    ", s);
      Console.Write("$    ");
      foreach (string s in neterminale)
        Console.Write("{0}   ", s);
      Console.WriteLine();
      for (int i = 0; i < randuri; i++)
      {
        if (i < 10)
          Console.Write("{0} |", i);
        else
          Console.Write("{0}|", i);
        foreach (string s in terminale)
          Console.Write("{0}   ", tabelaActiuniSiSalt[(i, Char.Parse(s))]);
        Console.Write("{0}   ", tabelaActiuniSiSalt[(i, '$')]);
        foreach (string s in neterminale)
          Console.Write("{0}   ", tabelaActiuniSiSalt[(i, Char.Parse(s))]);
        Console.WriteLine();
      }
    }

    public void Citire()
    {
      int i = 0;
      foreach (string line in File.ReadLines(@".\fin.txt"))
      {
        switch (i)
        {
          case 0:
            neterminale = line.Split(",").ToList();
            break;

          case 1:
            terminale = line.Split(",").ToList();
            break;

          default:
            productii.Add(line);
            break;
        }
        i++;
      }
    }

    public void Afisare()
    {
      Console.Write("Neterminale sunt: ");
      foreach (string n in neterminale)
        Console.Write("{0} ", n);
      Console.WriteLine();
      Console.Write("Terminale sunt: ");
      foreach (string t in terminale)
        Console.Write("{0} ", t);
      Console.WriteLine();
      foreach (string t in productii)
        Console.WriteLine("{0}", t);
      Console.WriteLine();
    }

    public void VerificareGramatica()
    {
      Queue<char> queue = new();
      Stack<string> stack = new();
      foreach (char s in sir)
      {
        queue.Enqueue(s);
      }
      stack.Push("$");
      stack.Push("0");
      char caracter = queue.Peek();
      try
      {
        while (tabelaActiuniSiSalt[(int.Parse(stack.Peek()), caracter)] != "00" && tabelaActiuniSiSalt[(int.Parse(stack.Peek()), caracter)] != "ac")
          switch (tabelaActiuniSiSalt[(int.Parse(stack.Peek()), caracter)][0])
          {
            case 'r':
              int vf = int.Parse(stack.Peek());
              int nrexpr = int.Parse(tabelaActiuniSiSalt[(vf, caracter)][1..]) - 1;
              string[] termeni = productii[nrexpr].Split("->");
              char neterminal = char.Parse(termeni[0]);
              int nr = termeni[1].Length * 2;
              while (nr > 0)
              {
                nr--;
                stack.Pop();
              }
              string n = tabelaActiuniSiSalt[(int.Parse(stack.Peek()), neterminal)];
              stack.Push(neterminal.ToString());
              stack.Push(n.ToString());
              break;

            case 'd':
              int vf2 = int.Parse(stack.Peek());
              stack.Push(caracter.ToString());
              stack.Push(tabelaActiuniSiSalt[(vf2, caracter)][1..]);
              queue.Dequeue();
              caracter = queue.Peek();
              break;
          }
        switch (tabelaActiuniSiSalt[(int.Parse(stack.Peek()), caracter)])
        {
          case "00":
            Console.WriteLine("EROARE!");
            break;

          case "ac":
            Console.WriteLine("Acceptat");
            stack.Push(queue.Peek().ToString());
            break;
        }
      }
      catch(Exception ex)
      {
        Console.WriteLine("EROARE");
      }
    }

    public void Tabela(string filePath)
    {
      Tabela tabela = new(terminale, neterminale, productii);
      tabela.LoadGrammar(filePath);
      //tabela.loadData("show");
    }
  }
}
