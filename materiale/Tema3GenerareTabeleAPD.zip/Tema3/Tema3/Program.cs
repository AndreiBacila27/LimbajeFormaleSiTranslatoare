namespace GramaticiLR1
{
  internal class Program
  {
    private static void Main()
    {
      string filePath = @".\tabelagenerata.txt";
      string sir = "a*-(a-a)+a*a$";
      Gramatica g = new(sir);
      g.Tabela(filePath);
      g.CitireTabela(filePath);
      g.AfisareTabela();
      Console.WriteLine();
      Console.WriteLine("Verficam daca sirul este acceptat " + sir);
      Console.WriteLine();
      g.VerificareGramatica();
    }
  }
}
